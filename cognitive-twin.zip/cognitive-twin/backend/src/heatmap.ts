// Heatmap logic is now handled client-side in the Next.js frontend.
// This file is kept as a placeholder to avoid breaking imports.
export {};
